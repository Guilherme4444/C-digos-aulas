
import subclasse.Arrara;
import subclasse.Ave;
import subclasse.Cachorro;
import subclasse.Cobra;
import subclasse.Mamifero;
import subclasse.Peixe;
import subclasse.Reptil;
import subclasse.Tartaturaga;
import superclasse.Animal;

public class Principal {
    public static void main(String[] args) throws Exception {
        //Animal a = new Animal(50.0, 5, 4);
        Mamifero m = new Mamifero(55.0, 17, 2,
         "preto");
         
         Reptil r = new Reptil(0.500, 4, 0,
          "verde neon");

          Peixe p = new Peixe(0.300, 1, 1,
          "rozelha");

          Ave a = new Ave(0.200, 5, 2, "azul celeste");
        
        m.alimentar();
        r.alimentar();
        p.alimentar();
        a.alimentar();

        System.out.println();
        Veterinario v = new Veterinario();
        v.atendeAnimal(m);
        System.out.println();
        v.atendeAnimal(r);
        System.out.println();
        v.atendeAnimal(p);
        System.out.println();
        v.atendeAnimal(a);

        Tartaturaga t = new Tartaturaga(100, 50,
         4, "verde");

         Cobra c = new Cobra(2, 3, 0, "amarelo");

         //c.locomover();

         //t.locomover();

         v.atendeAnimal(c);
         v.atendeAnimal(t);

         Cachorro toto = new Cachorro(16, 12, 3, "verde agua");

         System.out.println();
         v.reagir(c);
         v.reagir(toto);
    }

    public static Animal fabricaDeAnimais(String tipoAnimal){
        if(tipoAnimal.equals("cachorro")){
            Cachorro c = new Cachorro(0.0, 0, 4, "azul bebe");
            return c;
        }else if(tipoAnimal.equals("cobra")){
            Cobra co = new Cobra(0.0, 0, 0, "cinza");
            return co;
        }else if(tipoAnimal.equals("arrara")){
            Arrara a = new Arrara(0.0, 0, 2, "Azul");
            return a;
        }else{
            Peixe p = new Peixe(0.0, 0, 0, "prata");
            return p;
        }        
    }
}
