package subclasse;

public class Arrara extends Ave{
    public Arrara(double peso, int idade, int numeroMembro, String corPena) {
        super(peso, idade, numeroMembro, corPena);
    }
}