package subclasse;

public class Lobo extends Mamifero{

    public Lobo(double peso, int idade, int numeroMembro, String corDePelo) {
        super(peso, idade, numeroMembro, corDePelo);
    }

    public void emitirSom() {
        System.out.println("Auuuuuuuuuu!!!");
    }   
    
}
