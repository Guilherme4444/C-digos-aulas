package subclasse;

public class Tartaturaga extends Reptil {

    public Tartaturaga(double peso, int idade, int numeroMembro, String corEscama) {
        super(peso, idade, numeroMembro, corEscama);
    }
    
    public void locomover(){
        System.out.println("A Tartaruga anda beemmm devagar");
    }
}
