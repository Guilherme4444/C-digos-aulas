package subclasse;

public class Cobra extends Reptil{

    public Cobra(double peso, int idade, int numeroMembro, String corEscama) {
        super(peso, idade, numeroMembro, corEscama);
    }   
    
}
