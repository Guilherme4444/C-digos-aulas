package subclasse;

public class Cachorro extends Mamifero{

    public Cachorro(double peso, int idade, int numeroMembro, String corDePelo) {
        super(peso, idade, numeroMembro, corDePelo);
    }

    public Cachorro geraObjetoCachorro(){
        Cachorro c = new Cachorro(0.0, 0, 4, "caramelo");
        return c;
    }
    
    public void enterrarOssos(){
        System.out.println("Cachorro está enterrando ossos");
    }

    public void abanarRabo(){
        System.out.println("Cachorro está feliz, e abana o rabo");
    }

    public void emitirSom(){
        System.out.println("au! au! au!");
    }

    public void reagir(String frase){
        if(frase.equals("toma comida") || frase.equals("vamo passea")
            || frase.equals("Olá")){
            System.out.println("Abanar rabo e latir");
        }else{
            System.out.println("rosnar");
        }
    }

    public void reagir(int hora, int min){
        if(hora < 12){
            System.out.println("Abanar o rabo");
        }else if(hora >= 12 && hora < 18){
            System.out.println("Abanar o rabo e latir");
        }else{
            System.out.println("ignorar");
        }
    }

    public void reagir(boolean dono){
        if(dono){
            System.out.println("Abanar o rabo");
        }else{
            System.out.println("Rosnar e latir");
        }
    }

    public void reagir(){
        if(this.idade < 7){
            if(this.peso < 15.0){
                System.out.println("Abanar o rabo");
            }else{
                System.out.println("Latir");
            }
        }else{
            if(this.peso < 15.0){
                System.out.println("Rosnar");
            }else{
                System.out.println("ignorar");
            }
        }
    }
    
}
