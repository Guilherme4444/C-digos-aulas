package subclasse;

public class PeixinhoDourado extends Peixe{
    public PeixinhoDourado(double peso, int idade, int numeroMembro, String corEscama) {        
        super(peso, idade, numeroMembro, corEscama);        
    }    
}